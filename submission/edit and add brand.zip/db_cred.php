<?php
//Database credentials
define("DATABASE", "shoppin");
define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWD", "");

?>
